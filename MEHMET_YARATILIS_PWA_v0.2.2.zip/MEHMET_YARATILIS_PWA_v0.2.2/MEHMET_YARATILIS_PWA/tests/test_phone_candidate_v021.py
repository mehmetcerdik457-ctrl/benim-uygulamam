from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'MEHMET.html').read_text();js=(ROOT/'app.js').read_text();sw=(ROOT/'sw.js').read_text();man=json.loads((ROOT/'manifest.webmanifest').read_text());loc=json.loads((ROOT/'locales/core.json').read_text())
checks={
 'relative_api_paths':"bridge('./api/health')" in js and "bridge('/api/health')" not in js,
 'https_secure_context_status':'window.isSecureContext' in js,
 'pwa_install_prompt':'beforeinstallprompt' in js and 'appinstalled' in js,
 'service_worker_ready':'navigator.serviceWorker.ready' in js,
 'offline_navigation_fallback':'navigationResponse' in sw and "caches.match('./MEHMET.html')" in sw,
 'indexeddb_restore':'restoreChats()' in js and "all('chats')" in js,
 'reopen_probe':'mehmet_reopen_marker' in js,
 'file_sha256':'crypto.subtle.digest' in js,
 'camera_stream':'getUserMedia({video:' in js and 'canvas.toBlob' in js,
 'microphone_record':'getUserMedia({audio:true})' in js and 'MediaRecorder' in js,
 'tts_completion':'u.onstart' in js and 'u.onend' in js,
 'i18n_17':len(loc['locales'])==17 and all(len(v)>=40 for v in loc['locales'].values()),
 'task_history':"add('tasks'" in js and 'renderTasks' in js,
 'error_log':"add('logs'" in js and 'redact(' in js,
 'model_fail_closed':"sahte model cevabı üretilmedi" in js,
 'research_disabled_initial':bool(re.search(r'id="researchButton"[^>]*disabled',html)),
 'owner_disabled':bool(re.search(r'id="ownerProvision"[^>]*disabled',html)),
 'phone_entrypoint':(ROOT/'index.html').is_file(),
 'manifest_installable':man.get('display')=='standalone' and man.get('start_url')=='./MEHMET.html',
}
failed=[k for k,v in checks.items() if not v]
assert not failed,failed
print('PHONE_CANDIDATE_STATIC_PASS',json.dumps(checks,ensure_ascii=False))
