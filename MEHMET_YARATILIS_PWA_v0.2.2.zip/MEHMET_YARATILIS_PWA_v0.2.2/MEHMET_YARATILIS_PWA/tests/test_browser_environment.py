"""Diagnose whether this execution environment permits real browser navigation."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 pg=b.new_page()
 try:
  pg.goto('file://'+str(ROOT/'MEHMET.html'),wait_until='domcontentloaded',timeout=8000)
  print('BROWSER_NAVIGATION_PASS')
 except Exception as e:
  msg=str(e)
  if 'ERR_BLOCKED_BY_ADMINISTRATOR' in msg: print('BROWSER_NAVIGATION_BLOCKED_BY_ADMINISTRATOR')
  else: raise
 finally:b.close()
