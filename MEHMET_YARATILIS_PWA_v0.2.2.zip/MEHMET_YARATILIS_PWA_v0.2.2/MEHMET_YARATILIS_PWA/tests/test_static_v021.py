from pathlib import Path
import json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
required=['index.html','MEHMET.html','app.js','styles.css','manifest.webmanifest','sw.js','locales/core.json','icons/icon-192.png','icons/icon-512.png','bridge/MEHMET_GUVENLI_KOPRU.py','bridge/provider_adapters.py','bridge/vault.py','bridge/owner_identity.py','START_HERE.md','VERSION.txt','vercel.json','records/ORIGINAL_BOT_CAPABILITY_MATRIX.md']
for f in required:
 p=ROOT/f; assert p.is_file() and p.stat().st_size>0, f
html=(ROOT/'MEHMET.html').read_text(encoding='utf-8'); js=(ROOT/'app.js').read_text(encoding='utf-8'); sw=(ROOT/'sw.js').read_text(encoding='utf-8')
assert (ROOT/'index.html').read_bytes()==(ROOT/'MEHMET.html').read_bytes()
assert 'v0.2.2' in html and "APP_VERSION='0.2.2'" in js and "mehmet-pwa-v0.2.2" in sw
man=json.loads((ROOT/'manifest.webmanifest').read_text()); assert man['start_url']=='./MEHMET.html' and man['scope']=='./' and man['display']=='standalone'
assert {'192x192','512x512'} <= {x['sizes'] for x in man['icons']}
loc=json.loads((ROOT/'locales/core.json').read_text()); assert len(loc['locales'])==17
html_keys=set(re.findall(r'data-i18n="([^"]+)"',html)); ph_keys=set(re.findall(r'data-i18n-placeholder="([^"]+)"',html)); required_keys=html_keys|ph_keys|{'stop'}
for code,d in loc['locales'].items():
 missing=required_keys-set(d); assert not missing,(code,sorted(missing)); assert len(d)>=40,(code,len(d))
assert 'getUserMedia({video:' in js and 'canvas.toBlob' in js and 'MediaRecorder' in js
assert 'u.onstart' in js and 'u.onend' in js and 'TTS_TIMEOUT' in js
assert 'crypto.subtle.digest' in js and 'restoreChats()' in js and 'persistenceProbe()' in js
assert "$('#researchButton').disabled=!state.researchConfigured" in js
assert "navigator.serviceWorker.register('./sw.js')" in js and "await navigator.serviceWorker.ready" in js
assert "./index.html" in sw and "./MEHMET.html" in sw and "./locales/core.json" in sw and "/api/" in sw
# Every interactive button must either have a JS handler, be explicitly disabled, be a data-panel nav button, or be the submit button in memoryForm.
button_tags=re.findall(r'<button\b([^>]*)>(.*?)</button>',html,re.S)
unresolved=[]
for attrs,body in button_tags:
 bid=re.search(r'id="([^"]+)"',attrs)
 if bid:
  idv=bid.group(1)
  if idv=='sendButton' and 'id="composer"' in html: continue
  if f"#{idv}" not in js and 'disabled' not in attrs: unresolved.append(idv)
 else:
  if 'data-panel=' in attrs: continue
  text=re.sub(r'<[^>]+>','',body).strip()
  if text=='Kaydet' and 'id="memoryForm"' in html: continue
  unresolved.append('NO_ID:'+text)
assert not unresolved,unresolved
# Explicitly non-operational critical actions are disabled.
assert re.search(r'id="ownerProvision"[^>]*disabled',html)
assert re.search(r'id="researchButton"[^>]*disabled',html)
# Runtime source secret scan (tests/evidence/records excluded).
scan=[]
for p in [ROOT/'MEHMET.html',ROOT/'index.html',ROOT/'app.js',ROOT/'manifest.webmanifest',ROOT/'sw.js',ROOT/'locales/core.json',*sorted((ROOT/'bridge').glob('*.py'))]:
 scan.append(p.read_text(encoding='utf-8',errors='ignore'))
blob='\n'.join(scan)
for pat in [r'\bsk-[A-Za-z0-9_-]{20,}',r'api[_-]?key\s*[:=]\s*["\'][^"\']{12,}']:
 assert not re.search(pat,blob,re.I),pat
subprocess.run(['node','--check',str(ROOT/'app.js')],check=True,capture_output=True)
for p in (ROOT/'bridge').glob('*.py'): subprocess.run([sys.executable,'-m','py_compile',str(p)],check=True,capture_output=True)
print('STATIC_V022_PASS I18N_17_PASS FAKE_BUTTONS_0_PASS')

assert "bridge('./api/health')" in js and "bridge('/api/health')" not in js
