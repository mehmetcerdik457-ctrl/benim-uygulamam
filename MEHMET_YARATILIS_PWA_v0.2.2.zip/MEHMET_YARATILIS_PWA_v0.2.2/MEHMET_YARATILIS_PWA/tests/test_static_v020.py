from pathlib import Path
import json,re,hashlib,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
required=['MEHMET.html','app.js','styles.css','manifest.webmanifest','sw.js','locales/core.json','icons/icon-192.png','icons/icon-512.png','bridge/MEHMET_GUVENLI_KOPRU.py','bridge/provider_adapters.py','bridge/vault.py','bridge/owner_identity.py']
for f in required:
 p=ROOT/f; assert p.is_file() and p.stat().st_size>0, f
html=(ROOT/'MEHMET.html').read_text(encoding='utf-8')
js=(ROOT/'app.js').read_text(encoding='utf-8')
sw=(ROOT/'sw.js').read_text(encoding='utf-8')
man=json.loads((ROOT/'manifest.webmanifest').read_text())
loc=json.loads((ROOT/'locales/core.json').read_text())
assert 'v0.2.0' in html
assert man['start_url']=='./MEHMET.html' and man['scope']=='./'
assert {'192x192','512x512'} <= {x['sizes'] for x in man['icons']}
assert len(loc['locales'])==17 and {'tr','en','ar'} <= set(loc['locales'])
assert "const DB_NAME='mehmet_pwa_v1'" in js and "const DB_VERSION=2" in js
assert 'restoreChats()' in js and 'persistenceProbe()' in js
assert "$('#researchButton').disabled=!state.researchConfigured" in js
assert 'renderProviderSelect' in js and '/api/providers' in js
assert 'crypto.subtle.digest' in js
assert 'getUserMedia({video:' in js and 'MediaRecorder' in js and 'speechSynthesis' in js
assert 'beforeinstallprompt' in js and 'appinstalled' in js
assert "./locales/core.json" in sw and "mehmet-pwa-v0.2.0" in sw
# No obvious raw API key/token patterns in source.
blob='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in ROOT.rglob('*') if p.is_file() and p.suffix in {'.js','.py','.html','.json','.md','.txt'})
for pat in [r'\bsk-[A-Za-z0-9_-]{20,}',r'Bearer\s+[A-Za-z0-9._~-]{20,}',r'api[_-]?key\s*[:=]\s*["\'][^"\']{12,}']:
 assert not re.search(pat,blob,re.I), pat
subprocess.run(['node','--check',str(ROOT/'app.js')],check=True,capture_output=True)
for p in (ROOT/'bridge').glob('*.py'):
 subprocess.run([sys.executable,'-m','py_compile',str(p)],check=True,capture_output=True)
# v0.1 rollback snapshot must match Drive release core hashes.
expected={
'MEHMET.html':'d922393c96accdf8f9b27c17798f3c04be25c51fbd5d860a8667ed598b86b875',
'app.js':'824cbb586e1cf6623e43db1863586e24966e68d3fc1b46e3c120011ca8abf7d4',
'styles.css':'170b6d396ad3da99150ba6f408e828bed69e2263d5946d429e1a6088c2f6f594',
'manifest.webmanifest':'98ea900919b8d9b7c098684afabfbff4ec1ae59df9970a7c029c9da1066c91ec',
'sw.js':'1af14a37f30db3caaabc84a883a44ae2ac0679cc291c0804e478f5ac36043501'}
for n,h in expected.items():
 got=hashlib.sha256((ROOT/'SNAPSHOT/v0.1.0'/n).read_bytes()).hexdigest(); assert got==h,(n,got,h)
print('STATIC_V020_PASS')
