from pathlib import Path
import importlib.util,sys,threading,json,urllib.request,urllib.error,os
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'bridge'))
import MEHMET_GUVENLI_KOPRU as bridge

def request(url,method='GET',obj=None):
 data=None if obj is None else json.dumps(obj).encode()
 req=urllib.request.Request(url,data=data,method=method,headers={'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=4) as r:return r.status,json.loads(r.read())
 except urllib.error.HTTPError as e:return e.code,json.loads(e.read())

srv=ThreadingHTTPServer(('127.0.0.1',0),bridge.Handler); threading.Thread(target=srv.serve_forever,daemon=True).start(); base=f'http://127.0.0.1:{srv.server_port}'
try:
 s,j=request(base+'/api/health'); assert s==200 and j['status']=='PASS' and j['version']=='0.2.0'
 s,j=request(base+'/api/vault/status'); assert s==200 and j['status']=='UNCONFIGURED' and 'configured_secret_count' in j
 s,j=request(base+'/api/providers'); assert s==200 and j['providers']==[] and j['research_configured'] is False
 s,j=request(base+'/api/owner/status'); assert s==200 and j['runtime']=='UNPROVISIONED'; assert set(['OWNER_ID','TRUSTED_DEVICE_ID','SESSION_ID','SESSION_EXPIRY','AUTH_LEVEL','CHALLENGE_ID','CHALLENGE_EXPIRY','AUTH_METHOD','LAST_VERIFIED_AT','AUDIT_ID']) <= set(j['owner'])
 s,j=request(base+'/api/chat','POST',{'message':'test','provider':None}); assert s==503 and j['error']=='MODEL_PROVIDER_UNCONFIGURED'
 s,j=request(base+'/api/research','POST',{'query':'test'}); assert s==503 and j['error']=='RESEARCH_PROVIDER_UNCONFIGURED'
 s,j=request(base+'/api/owner/challenge','POST',{}); assert s==423 and j['error']=='OWNER_AUTH_UNPROVISIONED'
finally: srv.shutdown();srv.server_close()

# Mock-provider integration proves the adapter path, not an external/real model credential.
class Mock(BaseHTTPRequestHandler):
 def do_POST(self):
  n=int(self.headers.get('Content-Length','0')); body=json.loads(self.rfile.read(n));
  if self.path=='/v1/chat/completions':
   assert self.headers.get('Authorization')=='Bearer DUMMY_KEY'; raw=json.dumps({'choices':[{'message':{'content':'MOCK_PROVIDER_OK'}}]}).encode()
  elif self.path=='/research':
   assert self.headers.get('Authorization')=='Bearer DUMMY_RESEARCH'; raw=json.dumps({'text':'MOCK_RESEARCH_OK'}).encode()
  else:self.send_response(404);self.end_headers();return
  self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
 def log_message(self,*a):pass
mock=ThreadingHTTPServer(('127.0.0.1',0),Mock);threading.Thread(target=mock.serve_forever,daemon=True).start()
os.environ.update({
'MEHMET_PROVIDER_LOCAL_BASE_URL':f'http://127.0.0.1:{mock.server_port}/v1',
'MEHMET_PROVIDER_LOCAL_MODEL':'mock-model',
'MEHMET_SECRET_LOCAL_API_KEY':'DUMMY_KEY',
'MEHMET_RESEARCH_URL':f'http://127.0.0.1:{mock.server_port}/research',
'MEHMET_SECRET_RESEARCH_API_KEY':'DUMMY_RESEARCH'})
srv=ThreadingHTTPServer(('127.0.0.1',0),bridge.Handler);threading.Thread(target=srv.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{srv.server_port}'
try:
 s,j=request(base+'/api/providers'); assert s==200 and any(p['id']=='local' and p['configured'] for p in j['providers']) and j['research_configured'] is True
 s,j=request(base+'/api/chat','POST',{'provider':'local','message':'hello','attachments':[]}); assert s==200 and j['text']=='MOCK_PROVIDER_OK' and j['model']=='mock-model'
 s,j=request(base+'/api/research','POST',{'query':'hello'}); assert s==200 and j['text']=='MOCK_RESEARCH_OK'
 # Public endpoints must not leak raw test secrets.
 joined=json.dumps([request(base+'/api/vault/status')[1],request(base+'/api/providers')[1]])
 assert 'DUMMY_KEY' not in joined and 'DUMMY_RESEARCH' not in joined
finally:
 srv.shutdown();srv.server_close();mock.shutdown();mock.server_close()
 for k in ['MEHMET_PROVIDER_LOCAL_BASE_URL','MEHMET_PROVIDER_LOCAL_MODEL','MEHMET_SECRET_LOCAL_API_KEY','MEHMET_RESEARCH_URL','MEHMET_SECRET_RESEARCH_API_KEY']:os.environ.pop(k,None)
print('BRIDGE_V020_PASS MOCK_ADAPTER_E2E_PASS')
