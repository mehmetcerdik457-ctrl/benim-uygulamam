from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parents[1]
lines=(ROOT/'HASH_MANIFEST.txt').read_text().splitlines()
rows=[]
for line in lines:
 if not line or line.startswith('#') or '=' in line: continue
 h,size,rel=line.split('  ',2);rows.append((h,int(size),rel))
assert rows
for h,size,rel in rows:
 p=ROOT/rel;assert p.is_file(),rel;assert p.stat().st_size==size,(rel,p.stat().st_size,size);assert hashlib.sha256(p.read_bytes()).hexdigest()==h,rel
print(f'INTERNAL_HASH_MANIFEST_V022_PASS {len(rows)}/{len(rows)}')
