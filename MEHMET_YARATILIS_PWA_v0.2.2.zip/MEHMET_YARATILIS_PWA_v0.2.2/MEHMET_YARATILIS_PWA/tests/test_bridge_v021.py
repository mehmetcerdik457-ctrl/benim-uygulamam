from pathlib import Path
import sys,threading,json,urllib.request,urllib.error,os
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'bridge'))
import MEHMET_GUVENLI_KOPRU as bridge

def req(url,method='GET',obj=None):
 data=None if obj is None else json.dumps(obj).encode(); r=urllib.request.Request(url,data=data,method=method,headers={'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(r,timeout=5) as x:return x.status,x.headers, x.read()
 except urllib.error.HTTPError as e:return e.code,e.headers,e.read()

def jreq(url,method='GET',obj=None):
 s,h,b=req(url,method,obj); return s,h,json.loads(b)

srv=ThreadingHTTPServer(('127.0.0.1',0),bridge.Handler);threading.Thread(target=srv.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{srv.server_port}'
try:
 s,h,j=jreq(base+'/api/health');assert s==200 and j=={'service':'MEHMET_GUVENLI_KOPRU','version':'0.2.2','status':'PASS'}
 s,h,j=jreq(base+'/api/vault/status');assert s==200 and j['status']=='UNCONFIGURED'
 s,h,j=jreq(base+'/api/providers');assert s==200 and j['providers']==[] and j['research_configured'] is False
 s,h,j=jreq(base+'/api/chat','POST',{'message':'x','provider':None});assert s==503 and j['error']=='MODEL_PROVIDER_UNCONFIGURED'
 s,h,j=jreq(base+'/api/research','POST',{'query':'x'});assert s==503 and j['error']=='RESEARCH_PROVIDER_UNCONFIGURED'
 s,h,j=jreq(base+'/api/owner/challenge','POST',{});assert s==423 and j['error']=='OWNER_AUTH_UNPROVISIONED'
 # Static candidate is actually served by the same bridge.
 for path in ['/','/index.html','/MEHMET.html','/app.js','/styles.css','/manifest.webmanifest','/sw.js','/locales/core.json','/icons/icon-192.png','/icons/icon-512.png']:
  s,h,b=req(base+path);assert s==200,(path,s);assert len(b)>0,path
finally:srv.shutdown();srv.server_close()

class Mock(BaseHTTPRequestHandler):
 def do_POST(self):
  n=int(self.headers.get('Content-Length','0'));json.loads(self.rfile.read(n)); auth=self.headers.get('Authorization')
  if self.path=='/v1/chat/completions': assert auth=='Bearer TEST_ONLY_MODEL'; raw=json.dumps({'choices':[{'message':{'content':'V022_MODEL_OK'}}]}).encode()
  elif self.path=='/research': assert auth=='Bearer TEST_ONLY_RESEARCH'; raw=json.dumps({'text':'V022_RESEARCH_OK'}).encode()
  else:self.send_response(404);self.end_headers();return
  self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
 def log_message(self,*a):pass
mock=ThreadingHTTPServer(('127.0.0.1',0),Mock);threading.Thread(target=mock.serve_forever,daemon=True).start()
os.environ.update({'MEHMET_PROVIDER_LOCAL_BASE_URL':f'http://127.0.0.1:{mock.server_port}/v1','MEHMET_PROVIDER_LOCAL_MODEL':'mock-v022','MEHMET_SECRET_LOCAL_API_KEY':'TEST_ONLY_MODEL','MEHMET_RESEARCH_URL':f'http://127.0.0.1:{mock.server_port}/research','MEHMET_SECRET_RESEARCH_API_KEY':'TEST_ONLY_RESEARCH'})
srv=ThreadingHTTPServer(('127.0.0.1',0),bridge.Handler);threading.Thread(target=srv.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{srv.server_port}'
try:
 s,h,j=jreq(base+'/api/providers');assert s==200 and any(x['id']=='local' and x['configured'] for x in j['providers']) and j['research_configured']
 s,h,j=jreq(base+'/api/chat','POST',{'provider':'local','message':'hello','attachments':[]});assert s==200 and j['text']=='V022_MODEL_OK'
 s,h,j=jreq(base+'/api/research','POST',{'query':'hello'});assert s==200 and j['text']=='V022_RESEARCH_OK'
 public=json.dumps([jreq(base+'/api/providers')[2],jreq(base+'/api/vault/status')[2]]);assert 'TEST_ONLY_MODEL' not in public and 'TEST_ONLY_RESEARCH' not in public
finally:
 srv.shutdown();srv.server_close();mock.shutdown();mock.server_close()
 for k in ['MEHMET_PROVIDER_LOCAL_BASE_URL','MEHMET_PROVIDER_LOCAL_MODEL','MEHMET_SECRET_LOCAL_API_KEY','MEHMET_RESEARCH_URL','MEHMET_SECRET_RESEARCH_API_KEY']:os.environ.pop(k,None)
print('BRIDGE_V022_PASS STATIC_SERVE_PASS FAIL_CLOSED_PASS MOCK_ADAPTER_E2E_PASS')
