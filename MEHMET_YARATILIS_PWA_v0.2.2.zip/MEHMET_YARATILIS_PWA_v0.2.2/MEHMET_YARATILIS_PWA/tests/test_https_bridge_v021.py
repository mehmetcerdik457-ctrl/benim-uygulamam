from pathlib import Path
import tempfile,subprocess,os,socket,time,urllib.request,ssl,json,signal
ROOT=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as td:
 cert=Path(td)/'cert.pem';key=Path(td)/'key.pem'
 subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(key),'-out',str(cert),'-days','1','-subj','/CN=localhost'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
 env=os.environ.copy();env.update({'MEHMET_HOST':'127.0.0.1','MEHMET_PORT':str(port),'MEHMET_TLS_CERT':str(cert),'MEHMET_TLS_KEY':str(key)})
 p=subprocess.Popen(['python3',str(ROOT/'bridge/MEHMET_GUVENLI_KOPRU.py')],cwd=str(ROOT),env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:
  deadline=time.time()+8; ok=False
  ctx=ssl._create_unverified_context() # test cert is deliberately self-signed; this verifies TLS wiring only.
  while time.time()<deadline:
   try:
    with urllib.request.urlopen(f'https://127.0.0.1:{port}/api/health',context=ctx,timeout=1) as r:
     j=json.loads(r.read());assert j['version']=='0.2.2' and j['status']=='PASS';ok=True;break
   except Exception: time.sleep(.15)
  assert ok,'HTTPS bridge did not become ready'
 finally:
  p.terminate()
  try:p.wait(timeout=3)
  except subprocess.TimeoutExpired:p.kill()
print('HTTPS_BRIDGE_TLS_HANDSHAKE_PASS SELF_SIGNED_TEST_ONLY_NOT_PUBLIC_TRUST')
