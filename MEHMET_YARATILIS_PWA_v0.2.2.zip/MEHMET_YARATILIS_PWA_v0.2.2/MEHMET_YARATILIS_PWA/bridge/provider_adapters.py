#!/usr/bin/env python3
from __future__ import annotations
from dataclasses import dataclass
import json, os, urllib.request, urllib.error, uuid
from vault import SecretVault

class ProviderError(RuntimeError): pass

@dataclass
class ProviderInfo:
    id:str; label:str; model:str; configured:bool

class OpenAICompatibleAdapter:
    """Minimal OpenAI-compatible chat adapter; endpoint/model/key stay server-side."""
    def __init__(self, provider_id:str, label:str, base_url:str, model:str, secret_name:str, vault:SecretVault):
        self.id=provider_id; self.label=label; self.base_url=base_url.rstrip('/'); self.model=model; self.secret_name=secret_name; self.vault=vault
    @property
    def configured(self): return bool(self.base_url and self.model and self.vault.get(self.secret_name))
    def info(self): return ProviderInfo(self.id,self.label,self.model,self.configured)
    def chat(self,message:str,attachments:list[dict]|None=None)->dict:
        key=self.vault.get(self.secret_name)
        if not self.configured or not key: raise ProviderError('PROVIDER_NOT_CONFIGURED')
        payload={"model":self.model,"messages":[{"role":"user","content":message}]}
        req=urllib.request.Request(self.base_url+"/chat/completions",data=json.dumps(payload).encode(),headers={"Authorization":"Bearer "+key,"Content-Type":"application/json"},method="POST")
        try:
            with urllib.request.urlopen(req,timeout=60) as r: obj=json.loads(r.read())
        except Exception as e: raise ProviderError(f'PROVIDER_HTTP_ERROR:{type(e).__name__}') from e
        try: text=obj['choices'][0]['message']['content']
        except Exception as e: raise ProviderError('PROVIDER_RESPONSE_INVALID') from e
        if not isinstance(text,str) or not text.strip(): raise ProviderError('PROVIDER_RESPONSE_EMPTY')
        return {"text":text,"provider":self.id,"model":self.model,"request_id":str(uuid.uuid4())}

class HttpResearchAdapter:
    def __init__(self,vault:SecretVault):
        self.url=os.environ.get('MEHMET_RESEARCH_URL','').strip()
        self.secret_name=os.environ.get('MEHMET_RESEARCH_SECRET_NAME','RESEARCH_API_KEY')
        self.vault=vault
    @property
    def configured(self): return bool(self.url and self.vault.get(self.secret_name))
    def research(self,query:str)->dict:
        key=self.vault.get(self.secret_name)
        if not self.configured or not key: raise ProviderError('RESEARCH_PROVIDER_UNCONFIGURED')
        req=urllib.request.Request(self.url,data=json.dumps({"query":query}).encode(),headers={"Authorization":"Bearer "+key,"Content-Type":"application/json"},method='POST')
        try:
            with urllib.request.urlopen(req,timeout=60) as r: obj=json.loads(r.read())
        except Exception as e: raise ProviderError(f'RESEARCH_HTTP_ERROR:{type(e).__name__}') from e
        text=obj.get('text') or obj.get('answer')
        if not isinstance(text,str) or not text.strip(): raise ProviderError('RESEARCH_RESPONSE_INVALID')
        return {"text":text,"request_id":str(uuid.uuid4())}

def build_providers(vault:SecretVault):
    specs=[]
    # A provider is exposed only if it has at least endpoint/model metadata. Secret status remains server-side.
    for pid,label in [('OPENAI','OpenAI-compatible'),('ANTHROPIC_PROXY','Anthropic-compatible proxy'),('GOOGLE_PROXY','Google-compatible proxy'),('LOCAL','Local OpenAI-compatible')]:
        base=os.environ.get(f'MEHMET_PROVIDER_{pid}_BASE_URL','').strip()
        model=os.environ.get(f'MEHMET_PROVIDER_{pid}_MODEL','').strip()
        secret=os.environ.get(f'MEHMET_PROVIDER_{pid}_SECRET_NAME',f'{pid}_API_KEY')
        if base or model:
            specs.append(OpenAICompatibleAdapter(pid.lower(),label,base,model,secret,vault))
    return specs
