#!/usr/bin/env python3
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import os, uuid

def iso_now(): return datetime.now(timezone.utc).isoformat()

@dataclass
class OwnerIdentity:
    OWNER_ID:str='MEHMET-CERDIK'
    TRUSTED_DEVICE_ID:str='UNPROVISIONED'
    SESSION_ID:str='NONE'
    SESSION_EXPIRY:str='NONE'
    AUTH_LEVEL:str='LOCKED'
    CHALLENGE_ID:str='NONE'
    CHALLENGE_EXPIRY:str='NONE'
    AUTH_METHOD:str='UNPROVISIONED'
    LAST_VERIFIED_AT:str='NEVER'
    AUDIT_ID:str='NONE'
    def public_dict(self): return asdict(self)

def current_owner() -> tuple[OwnerIdentity,str]:
    device=os.environ.get('MEHMET_OWNER_TRUSTED_DEVICE_ID')
    # No secret/biometric emulation: absence means fail closed.
    if not device: return OwnerIdentity(), 'UNPROVISIONED'
    return OwnerIdentity(TRUSTED_DEVICE_ID=device,AUTH_LEVEL='DEVICE_REGISTERED',AUTH_METHOD='DEVICE_ONLY',AUDIT_ID=str(uuid.uuid4())), 'PARTIAL_PROVISION'
