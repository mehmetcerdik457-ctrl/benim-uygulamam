#!/usr/bin/env python3
"""Server-side secret vault abstraction. Raw secret values are never serialized to clients."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import base64, json, os
from cryptography.fernet import Fernet, InvalidToken

@dataclass(frozen=True)
class VaultStatus:
    status: str
    backend: str
    configured_secret_count: int

class SecretVault:
    """Env-first secret provider with optional Fernet-encrypted file backend.

    Environment secret names use MEHMET_SECRET_<NAME>. An optional encrypted vault file
    may be enabled with MEHMET_VAULT_FILE and MEHMET_VAULT_MASTER_KEY. The master key is
    never read from disk by this module unless explicitly supplied in the environment.
    """
    PREFIX = "MEHMET_SECRET_"
    def __init__(self) -> None:
        self._file = Path(os.environ.get("MEHMET_VAULT_FILE", "")).expanduser() if os.environ.get("MEHMET_VAULT_FILE") else None
        self._master = os.environ.get("MEHMET_VAULT_MASTER_KEY")

    @staticmethod
    def _normalize(name: str) -> str:
        return "".join(ch if ch.isalnum() else "_" for ch in name.upper())

    def _env_name(self, name: str) -> str:
        return self.PREFIX + self._normalize(name)

    def _load_file(self) -> dict[str,str]:
        if not self._file or not self._file.exists() or not self._master:
            return {}
        try:
            token=self._file.read_bytes()
            raw=Fernet(self._master.encode()).decrypt(token)
            obj=json.loads(raw)
            return obj if isinstance(obj,dict) else {}
        except (InvalidToken, ValueError, OSError, json.JSONDecodeError):
            return {}

    def get(self, name: str) -> str | None:
        v=os.environ.get(self._env_name(name))
        if v: return v
        v=self._load_file().get(self._normalize(name))
        return v if isinstance(v,str) and v else None

    def configured_names(self) -> list[str]:
        names={k[len(self.PREFIX):] for k,v in os.environ.items() if k.startswith(self.PREFIX) and v}
        names.update(k for k,v in self._load_file().items() if isinstance(v,str) and v)
        return sorted(names)

    def status(self) -> VaultStatus:
        names=self.configured_names()
        backend="ENV"
        if self._file:
            backend="ENV+FERNET_FILE" if self._master else "ENV+FERNET_FILE_LOCKED"
        return VaultStatus("CONFIGURED" if names else "UNCONFIGURED",backend,len(names))

    @staticmethod
    def create_encrypted_file(path: str|Path, master_key: str, secrets: dict[str,str]) -> None:
        clean={SecretVault._normalize(k):v for k,v in secrets.items() if isinstance(v,str) and v}
        token=Fernet(master_key.encode()).encrypt(json.dumps(clean,separators=(",",":")).encode())
        p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(token); os.chmod(p,0o600)
