#!/usr/bin/env python3
"""MEHMET secure bridge v0.2.2. Provider secrets remain server-side and responses fail closed."""
from __future__ import annotations
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json, os, sys, ssl
from vault import SecretVault
from provider_adapters import build_providers, HttpResearchAdapter, ProviderError
from owner_identity import current_owner

ROOT=Path(__file__).resolve().parents[1]
MAX_BODY=1_000_000
vault=SecretVault()

def public_provider_state():
    ps=build_providers(vault); research=HttpResearchAdapter(vault)
    return ps,research

class Handler(SimpleHTTPRequestHandler):
    server_version='MEHMETBridge/0.2.2'
    def __init__(self,*a,**kw): super().__init__(*a,directory=str(ROOT),**kw)
    def _json(self,status,obj):
        raw=json.dumps(obj,ensure_ascii=False,separators=(',',':')).encode(); self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Content-Security-Policy',"default-src 'none'"); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def _body(self):
        try:
            n=int(self.headers.get('Content-Length','0')); assert 0<=n<=MAX_BODY
            obj=json.loads(self.rfile.read(n) or b'{}'); return obj if isinstance(obj,dict) else {}
        except Exception: return {}
    def do_GET(self):
        if self.path=='/api/health': return self._json(200,{'service':'MEHMET_GUVENLI_KOPRU','version':'0.2.2','status':'PASS'})
        if self.path=='/api/vault/status':
            s=vault.status(); return self._json(200,{'status':s.status,'backend':s.backend,'configured_secret_count':s.configured_secret_count})
        if self.path=='/api/providers':
            ps,research=public_provider_state(); return self._json(200,{'providers':[p.info().__dict__ for p in ps],'research_configured':research.configured})
        if self.path=='/api/owner/status':
            owner,runtime=current_owner(); return self._json(200,{'owner':owner.public_dict(),'runtime':runtime})
        return super().do_GET()
    def do_POST(self):
        body=self._body()
        if self.path=='/api/chat':
            msg=body.get('message'); pid=body.get('provider')
            if not isinstance(msg,str) or not msg.strip() or len(msg)>100_000: return self._json(400,{'error':'INVALID_MESSAGE'})
            ps,_=public_provider_state(); configured=[p for p in ps if p.configured]
            if not configured: return self._json(503,{'error':'MODEL_PROVIDER_UNCONFIGURED','message':'Yetkili model sağlayıcısı yapılandırılmadı.'})
            if not pid: return self._json(400,{'error':'PROVIDER_REQUIRED'})
            p=next((x for x in configured if x.id==pid),None)
            if not p: return self._json(404,{'error':'PROVIDER_NOT_CONFIGURED'})
            try: return self._json(200,p.chat(msg,body.get('attachments') or []))
            except ProviderError as e: return self._json(502,{'error':str(e)})
        if self.path=='/api/research':
            q=body.get('query'); _,research=public_provider_state()
            if not isinstance(q,str) or not q.strip() or len(q)>20_000: return self._json(400,{'error':'INVALID_QUERY'})
            if not research.configured: return self._json(503,{'error':'RESEARCH_PROVIDER_UNCONFIGURED','message':'Yetkili araştırma sağlayıcısı yapılandırılmadı.'})
            try: return self._json(200,research.research(q))
            except ProviderError as e: return self._json(502,{'error':str(e)})
        if self.path=='/api/owner/challenge':
            owner,runtime=current_owner()
            if runtime=='UNPROVISIONED': return self._json(423,{'error':'OWNER_AUTH_UNPROVISIONED','owner':owner.public_dict()})
            return self._json(501,{'error':'STRONG_OWNER_AUTH_NOT_IMPLEMENTED'})
        return self._json(404,{'error':'NOT_FOUND'})
    def log_message(self,fmt,*args): sys.stderr.write('[MEHMET_BRIDGE] '+(fmt%args)+'\n')

if __name__=='__main__':
    host=os.environ.get('MEHMET_HOST','127.0.0.1'); port=int(os.environ.get('MEHMET_PORT','8765'))
    srv=ThreadingHTTPServer((host,port),Handler)
    cert=os.environ.get('MEHMET_TLS_CERT'); key=os.environ.get('MEHMET_TLS_KEY')
    scheme='http'
    if cert and key:
        ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.load_cert_chain(cert,key);srv.socket=ctx.wrap_socket(srv.socket,server_side=True);scheme='https'
    print(f'MEHMET_GUVENLI_KOPRU {scheme}://{host}:{port}/MEHMET.html',flush=True)
    srv.serve_forever()
