#!/usr/bin/env python3
"""MEHMET secure bridge v0.1.0 — no provider secrets are exposed to the browser."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json, os, sys
ROOT=Path(__file__).resolve().parents[1]
PROVIDER_ENV_PREFIX='MEHMET_PROVIDER_'
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*a,**kw): super().__init__(*a,directory=str(ROOT),**kw)
    def _json(self,status,obj):
        raw=json.dumps(obj,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
    def _body(self):
        try:
            n=min(int(self.headers.get('Content-Length','0')),1_000_000);return json.loads(self.rfile.read(n) or b'{}')
        except Exception:return {}
    def do_GET(self):
        if self.path=='/api/health': return self._json(200,{'service':'MEHMET_GUVENLI_KOPRU','version':'0.1.0','status':'PASS'})
        if self.path=='/api/vault/status':
            providers=[k[len(PROVIDER_ENV_PREFIX):] for k,v in os.environ.items() if k.startswith(PROVIDER_ENV_PREFIX) and v]
            return self._json(200,{'status':'CONFIGURED' if providers else 'UNCONFIGURED','configured_provider_count':len(providers),'providers':providers})
        return super().do_GET()
    def do_POST(self):
        body=self._body()
        if self.path=='/api/chat': return self._json(503,{'error':'MODEL_PROVIDER_UNCONFIGURED','message':'Yetkili model sağlayıcısı güvenli köprüde yapılandırılmadı.'})
        if self.path=='/api/research': return self._json(503,{'error':'RESEARCH_PROVIDER_UNCONFIGURED','message':'Yetkili internet araştırma sağlayıcısı yapılandırılmadı.'})
        if self.path=='/api/owner/challenge': return self._json(423,{'error':'OWNER_AUTH_UNPROVISIONED','message':'Kriptografik Sahip oturumu henüz provision edilmedi.'})
        return self._json(404,{'error':'NOT_FOUND'})
    def log_message(self,fmt,*args): sys.stderr.write('[MEHMET_BRIDGE] '+(fmt%args)+'\n')
if __name__=='__main__':
    host=os.environ.get('MEHMET_HOST','127.0.0.1');port=int(os.environ.get('MEHMET_PORT','8765'))
    print(f'MEHMET_GUVENLI_KOPRU http://{host}:{port}/MEHMET.html',flush=True)
    ThreadingHTTPServer((host,port),Handler).serve_forever()
