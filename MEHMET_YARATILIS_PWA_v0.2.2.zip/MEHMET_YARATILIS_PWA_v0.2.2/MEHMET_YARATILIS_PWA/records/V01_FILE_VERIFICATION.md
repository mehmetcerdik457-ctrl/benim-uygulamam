# v0.1.0 DRIVE DOSYA DOĞRULAMA

Kaynak: Google Drive file id `1pgE9BJJu2LOXYC5jbu8nUdAAlhogt6YI` ham ZIP geri okuması; ZIP SHA-256 `ec7897b26e4b587aa7f82cead8940f6ec8e6e8d8edf00ce2f508b2089228d0ec`.

| Dosya | Var | Boyut | Boş | İçerik gerçek | Çalışan kod | SHA-256 | Drive geri okuma | Durum |
|---|---:|---:|---:|---:|---:|---|---:|---|
| MEHMET.html | EVET | 8198 | HAYIR | EVET | HTML shell | d922393c96accdf8f9b27c17798f3c04be25c51fbd5d860a8667ed598b86b875 | EVET | PASS |
| app.js | EVET | 11430 | HAYIR | EVET | EVET, browser runtime kısmi | 824cbb586e1cf6623e43db1863586e24966e68d3fc1b46e3c120011ca8abf7d4 | EVET | PARTIAL |
| styles.css | EVET | 5537 | HAYIR | EVET | CSS | 170b6d396ad3da99150ba6f408e828bed69e2263d5946d429e1a6088c2f6f594 | EVET | PASS |
| manifest.webmanifest | EVET | 432 | HAYIR | EVET | manifest | 98ea900919b8d9b7c098684afabfbff4ec1ae59df9970a7c029c9da1066c91ec | EVET | PARTIAL |
| sw.js | EVET | 754 | HAYIR | EVET | SW kodu var; runtime bloke | 1af14a37f30db3caaabc84a883a44ae2ac0679cc291c0804e478f5ac36043501 | EVET | PARTIAL |
| MEHMET_GUVENLI_KOPRU.py | EVET | 2431 | HAYIR | EVET | EVET, HTTP fail-closed | 7cfa8a52e022bd77f75625db768d4ebd34b9452eb65f775db6ae57a364a95a08 | EVET | PASS |
| DAVRANIS_HARITASI.md | EVET | 3936 | HAYIR | EVET | N/A | 05a08a40eda69b3912530704d43348b8b2e483c73246671e9ba41b78997174f0 | EVET | PASS |
| APK_AUDIT_REPORT.md | EVET | 7261 | HAYIR | EVET | N/A | be8f5a94b9f2bb3e0b39b9138492b4495632650465aa4a7a2ff60518c3c4691d | EVET | PASS |
| PROJECT_MANIFEST.json | EVET | 534 | HAYIR | EVET | N/A | bc50e1a1fd0a5d3a4eba7ac742a7dbb740b91b96d5e6655262bcd33d30c19ad1 | EVET | PASS |
| CURRENT_STATE.md | EVET | 527 | HAYIR | EVET | N/A | 95d1093316d463edbc5bc512e9e0b27548e62280ed7bfcdc00b64e065d61854f | EVET | PASS |
| HANDOFF.md | EVET | 381 | HAYIR | EVET | N/A | 06b217a3cfec6240dec0df0c6c54023a3dfa3f9b971aab62efb554ac265b0647 | EVET | PASS |
| RUN_LEDGER.jsonl | EVET | 1071 | HAYIR | EVET | JSONL parse edildi | a9acd9b7e1b9be99ecfca86491cd08ff717cd8db8c6f1e2450a1c62c44956a05 | EVET | PASS |
| TEST_REPORT.md | EVET | 675 | HAYIR | EVET | N/A | f17cd14ef40a5898663876db9cd4229da07615d6b3068c0c3c9d2f600c1d92ae | EVET | PASS |
| SNAPSHOT/v0.1.0 | EVET | 28782 toplam | HAYIR | EVET | core source snapshot | constituent manifest sha256 0d6c3d796538b0d28ae8f90880b4cd3e51561079b6dcffc965fba44b30ea20cb | EVET | PASS |
| HASH_MANIFEST.txt | EVET | 4168 | HAYIR | EVET | hash list | 5f244bdcca7510480b8fa943b67bea5c7eb0c093662e15cd83bce7a04ccbed5f | EVET | PASS |
| release ZIP | EVET | 102501 | HAYIR | EVET | taşınabilir artefact | ec7897b26e4b587aa7f82cead8940f6ec8e6e8d8edf00ce2f508b2089228d0ec | EVET | PASS |
