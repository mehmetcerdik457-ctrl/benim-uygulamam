# 06_GÜVENLİK_DEĞİŞMEZLERİ
Ham secret HTML/JS/Drive plaintext/log/model bağlamına yazılmaz. Provider secret yalnız server-side vault üzerinden çözülür. Provider ve research yoksa sahte sonuç üretilemez. Orijinal APK değiştirilemez.
