# 11_HATA_KAYDI
V01_CHAT_REOPEN_MISSING=ROOT_CAUSE:init chats store'u render etmiyordu; v0.2 restoreChats ile düzeltildi.
V01_LANGUAGE_VISUAL_ONLY=ROOT_CAUSE:language onchange handler/i18n data yoktu; v0.2 locales/core.json + applyLanguage ile düzeltildi.
V01_STATIC_MODEL_AVAILABILITY_MISLEADING=ROOT_CAUSE:hardcoded model labels provider durumu göstermiyordu; v0.2 dynamic provider registry.
BROWSER_TEST_BLOCKED=ENVIRONMENT:ERR_BLOCKED_BY_ADMINISTRATOR; uygulama PASS sayılmadı.
SECURITY_SCAN_FALSE_POSITIVE=TEST_DATA:dummy Bearer string güvenlik regex'ini tetikledi; test secret değerleri kısaltıldı, üretim sızıntısı bulunmadı.
