# 08_MODEL_KAYDI
Statik sahte model listesi kaldırıldı. /api/providers yalnız server konfigürasyon metadata'sı olan adapterları listeler. Desteklenen adapter sınıfı: OpenAI-compatible HTTP; local/proxy endpointlerle modüler. REAL_MODEL_PROVIDER=BLOCKED_PROVIDER_CREDENTIAL.
