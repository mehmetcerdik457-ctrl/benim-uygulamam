# v0.1.0 — 20 GERÇEK TEST
Kaynak: Google Drive’dan ham olarak geri indirilen v0.1.0 release ZIP.

1. **Ana sayfa gerçek yükleme** = BLOCKED — Headless Chromium ortam politikası ERR_BLOCKED_BY_ADMINISTRATOR; statik HTML gerçek.
2. **Sohbet giriş alanı** = PASS — #prompt + #composer gerçek HTML elemanları.
3. **Mesaj yazma** = PARTIAL — onsubmit→sendChat tanımlı; browser runtime bloke.
4. **Mesaj geçmişini IndexedDB’ye yazma** = PARTIAL — add('chats'
5. **Yeniden açılışta chat geçmişini geri yükleme** = FAIL — init() chats store okuyup messages UI’ye geri yüklemiyor.
6. **Model seçimi** = PASS — #modelSelect ve gerçek select seçenekleri mevcut.
7. **Provider yokken fail-closed** = PASS — v0.1 bridge /api/chat HTTP 503 tasarımı ve önceki HTTP testi.
8. **Sahte AI cevabı üretmeme** = PASS — Provider hatasında assistant cevabı uydurmak yerine system uyarısı gösteriyor.
9. **Dosya seçimi** = PARTIAL — File input + acceptFiles var; browser runtime bloke.
10. **Kamera browser capability** = PARTIAL — capture=environment input var; getUserMedia kamera akışı yok.
11. **Kamera gerçek runtime** = BLOCKED — Fiziksel cihaz/browser izin testi yok.
12. **Mikrofon browser capability** = PARTIAL — getUserMedia audio + MediaRecorder kodu var.
13. **Mikrofon gerçek runtime** = BLOCKED — Fiziksel mikrofon testi yok.
14. **TTS** = PARTIAL — speechSynthesis kodu var; gerçek ses çıkışı testi yok.
15. **Web research gerçek bağlantı** = PARTIAL — Düğme /api/research köprüsüne bağlı; provider UNCONFIGURED.
16. **Hafıza ekranı gerçek kayıt** = PARTIAL — all('memory')
17. **Görev geçmişi gerçek veri** = PARTIAL — all('tasks')
18. **Hata kaydı gerçek olay** = PARTIAL — window error + unhandledrejection + IndexedDB logs
19. **Service worker / offline shell** = PARTIAL — sw.js cache-first/network-fallback kodu var; gerçek registration runtime bloke.
20. **PWA installability** = PARTIAL — Manifest/display/start_url var; runtime install prompt test edilmedi ve sadece SVG icon kullanıyor.

Özet: PASS=4, PARTIAL=12, FAIL=1, BLOCKED=3.
