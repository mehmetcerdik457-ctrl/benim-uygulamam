# 10_KARŞILAŞTIRMA_KAYDI
v0.1→v0.2: chat restore eklendi; dil seçimi gerçek i18n binding kazandı; 17 locale core altyapısı eklendi; rooted manifest/SW yolları relative yapıldı; 192/512 PNG icon eklendi; provider listesi dinamik oldu; research unconfigured iken disabled; camera getUserMedia eklendi; attachment SHA-256 eklendi; log redaction güçlendirildi; owner/vault/provider modülleri ayrıldı.
