# 15_GERİ_ALMA_DİZİNİ
- v0.1.0 Drive release ID: 1pgE9BJJu2LOXYC5jbu8nUdAAlhogt6YI
  SHA256: ec7897b26e4b587aa7f82cead8940f6ec8e6e8d8edf00ce2f508b2089228d0ec
- v0.2.0 Drive release ID: 18W_6kn3UagfsYuzUW37cIwSyg1z1giYM
  SHA256: 2cf781b6b86ece9eec6e61d47352293410cab8d42e8423421a191ae07fd667f7
- v0.2.1: current release candidate; its Drive ID and release SHA are stored only in external RELEASE_CHECKSUMS_v0.2.1.txt after upload.
