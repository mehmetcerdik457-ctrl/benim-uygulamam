# 12_SÜRÜM_BİLDİRGESİ — v0.2.1
VERSION=0.2.1
BASE_VERSION=0.2.0
BASE_IMMUTABLE=true
DATE=2026-09-06
PURPOSE=Trusted-HTTPS / physical-phone runtime candidate
TEST_RESULT=PARTIAL_PASS
ROLLBACK_POINT=v0.2.0
ROLLBACK_SHA256=2cf781b6b86ece9eec6e61d47352293410cab8d42e8423421a191ae07fd667f7
KNOWN_LIMITATIONS=trusted HTTPS publish unavailable through current deploy connector schema; physical phone runtime unverified; real model/research providers absent; strong owner auth unprovisioned; phone bridge not implemented.
