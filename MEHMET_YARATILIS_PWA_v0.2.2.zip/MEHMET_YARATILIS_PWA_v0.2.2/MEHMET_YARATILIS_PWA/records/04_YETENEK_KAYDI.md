# 04_YETENEK_KAYDI
GERÇEK/KOD+TEST: statik PWA shell, bridge health, fail-closed, provider adapter mock E2E, secret vault interface, owner data model, file SHA-256 intake.
KISMİ/RUNTIME BEKLİYOR: IndexedDB browser reopen, service worker, PWA install prompt, kamera, mikrofon, TTS.
UNCONFIGURED: external model, web research.
