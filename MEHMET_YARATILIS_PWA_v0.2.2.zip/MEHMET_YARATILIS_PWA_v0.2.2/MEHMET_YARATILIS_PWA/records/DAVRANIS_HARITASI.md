# DAVRANIŞ HARİTASI — İLK SÜRÜM

Durum: statik APK kanıtına dayalı; runtime davranışları ayrıca belirtilmiştir.

## Sohbet
KULLANICI_NE_YAPIYOR → metin yazar/model seçer/gönderir  
UYGULAMA_NE_YAPIYOR → mesajı sohbet oturumuna ekler; limit/model kurallarını değerlendirir  
HANGİ_VERİYİ_KULLANIYOR → mesaj, chat geçmişi, seçili model, kişiselleştirme/hafıza olasılığı  
HANGİ_ARAÇ_VEYA_SERVİSE_GİDİYOR → **runtime backend doğrulanmadı**  
SONUÇ_NEREYE_GELİYOR → sohbet mesaj listesi  
SONUÇ_NASIL_GÖSTERİLİYOR → metin/markdown-math benzeri zengin içerik, kopyala/paylaş/düzenle/dinle eylemleri  
NEREYE_KAYDEDİLİYOR → history UI ve sqflite altyapısı var; kesin şema doğrulanmadı.

## Model seçimi
KULLANICI_NE_YAPIYOR → “Select Model & Tool” ekranından model seçer  
UYGULAMA_NE_YAPIYOR → model değişiminde mevcut sohbeti bitirip yenisini başlatabileceğini bildiren akış var  
HANGİ_VERİYİ_KULLANIYOR → model kimliği/limit/plan  
SERVİS → gerçek routing endpoint'i base APK içinde doğrulanmadı  
SONUÇ → yeni chat bağlamına seçili model etiketi uygulanır  
KAYIT → history filter model/tool filtresi tanımlı.

## Dosya / Görsel / Kamera / Video / Ses
KULLANICI → dosya, galeri, kamera, video veya audio seçer  
UYGULAMA → tip/sayı/boyut/süre limitleri uygular; bazı eski model seçimlerinde GPT-4o'ya geçiş diyaloğu kaynakları var  
VERİ → seçilen medya/dosya  
ARAÇ → Android FileProvider, image_picker, record/speech/audio bağımlılıkları  
SERVİS → multimodal analiz backend'i doğrulanmadı  
SONUÇ → sohbet içine eklenen attachment ve model cevabı  
KAYIT → chat geçmişine bağlanması bekleniyor, runtime gerekir.

## Voice Chat
KULLANICI → mikrofonla konuşur  
UYGULAMA → sesi yakalar, dil tanıma/transkripsiyon ve sesli yanıt akışı sunar  
VERİ → mikrofon audio + chat context  
ARAÇ → RECORD_AUDIO, SpeechRecognizer, TextToSpeech, just_audio/audio_session  
SERVİS → gerçek zamanlı AI backend doğrulanmadı  
SONUÇ → sesli yanıt + transcribed chat history  
KAYIT → kaynak metni “No audio recording saved” diyor; metin geçmişi tutulduğunu belirtiyor. Runtime doğrulanmalı.

## Web Search
KULLANICI → Web Search modunu açar ve sorgu gönderir  
UYGULAMA → “Searching / Analyzing” akışı ve görsel sonuç desteği gösterir  
VERİ → sorgu + canlı web sonuçları  
SERVİS → base APK statik taramasında arama backend endpoint'i doğrulanmadı  
SONUÇ → sohbet/web output  
KAYIT → chat history olasılığı; runtime gerekir.

## Deep Research
KULLANICI → Deep Research seçer  
UYGULAMA → Searching → Expanding → Organizing → Analyzing → Drafting durumları; tamamlanınca bildirim akışı  
VERİ → araştırma sorgusu + çoklu kaynaklar  
SERVİS → backend doğrulanmadı  
SONUÇ → araştırma raporu ve kaynaklar  
KAYIT → history + completion notification; runtime gerekir.

## Memory / Personalization
KULLANICI → Memory yönetir ve Chatbot AI'a kendisi/yanıt biçimi hakkında bilgi verir  
UYGULAMA → kişiselleştirmeyi yeni sohbetlere uygular; memory aç/kapat/sil/temizle akışları tanımlı  
VERİ → kullanıcı tercihleri ve konuşmalardan çıkarılan ayrıntılar  
SERVİS/DEPO → sqflite/shared_preferences mevcut ama memory'nin tam deposu doğrulanmadı  
SONUÇ → kişiselleştirilmiş yanıtlar  
KAYIT → geçici chat dışındaki oturumlar; kesin veri modeli runtime/decompilation gerektirir.

## Abonelik
KULLANICI → Pro/free trial/restore/manage subscription ekranlarını kullanır  
UYGULAMA → ürün/limit/paywall akışı, Google Play Billing 8.0.0  
VERİ → plan/ürün/satın alma durumu  
SERVİS → Google Play Billing  
SONUÇ → özellik/limit yetkisi  
KAYIT → satın alma durumu uygulama ve mağaza altyapısı; işlem testi yapılmadı.
