# 09_ARAÇ_KAYDI
Dosya: File API + SHA-256. Kamera: getUserMedia video + canvas capture. Mikrofon: getUserMedia audio + MediaRecorder. TTS: Web Speech. Research: server adapter, unconfigured ise UI disabled. Install: beforeinstallprompt. Offline: service worker.
