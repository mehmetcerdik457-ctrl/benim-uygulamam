# 07_HAFIZA_YAPISI
DB_NAME=mehmet_pwa_v1 korunarak geriye dönük uyumluluk sağlandı; DB_VERSION=2. Stores: memory,tasks,logs,settings,chats,runtime. v0.2 restoreChats() ekledi. persistenceProbe localStorage+IndexedDB önceki çalıştırma işaretini sonraki gerçek açılışta doğrular. Sandbox browser politikası nedeniyle otomatik process-reopen testi BLOCKED.
