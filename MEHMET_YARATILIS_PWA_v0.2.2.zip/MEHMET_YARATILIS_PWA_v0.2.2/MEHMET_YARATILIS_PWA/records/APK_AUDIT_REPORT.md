# ORIGINAL APK AUDIT — Chatbot AI 3.2.1

PROJECT_ID=MEHMET-AI-MASTER-CONTROL-001
AUDIT_TIME=2026-09-06T18:36:00+03:00
SOURCE=/mnt/data/Chatbot AI_3.2.1.apk
ORIGINAL_MODIFIED=false

## Dosya kimliği
- Boyut: 77,308,245 bayt
- SHA-256: `bbcf7838e942629ff4c7f6a25791d51ae76cad971f162d68d23e5f96bb600d65`
- SHA-1: `0cf05b970dc959d4c0c62682a1f3edecfc6f93ba`
- MD5: `5a0161278f78d82d3a9b5633d4967144`
- Paket: `com.codespaceapps.aichat`
- Uygulama etiketi: `Chatbot AI`
- Sürüm: `3.2.1` (`versionCode=893`)
- SDK: min 24, target 36, compile 36
- Ana Activity: `com.codespaceapps.aichat.MainActivity`
- Uygulama sınıfı: `com.pairip.application.Application`
- Flutter embedding: v2
- Split işareti: `android:requiredSplitTypes=base__abi,base__density`

## İmza kimliği
APK Signing Block bulundu. v2 (`0x7109871a`) ve v3 (`0xf05368c0`) signer sertifikaları aynı:
- Subject/Issuer: `CN=Android, OU=Android, O=Google Inc., L=Mountain View, ST=California, C=US`
- SHA-256: `7B:4A:4B:48:3A:D4:FD:FA:7B:CA:B3:C4:BA:9F:D5:A0:46:1C:AB:20:8F:C7:12:0A:4D:8D:2F:49:01:B3:A0:97`
- SHA-1: `D6:61:DD:FB:74:27:6A:00:E5:C9:0E:AC:7A:65:F4:11:1C:22:59:FA`
- 4096-bit RSA, SHA256withRSA

`jarsigner` APK'yi “unsigned JAR” olarak raporladı; bu, v1/JAR imzası olmadığını gösterir. APK Signing Block bağımsız parse edilerek v2/v3 sertifika kanıtı çıkarılmıştır.

## Manifest özeti
- İzin sayısı: 27
- Activity: 14
- Service: 17
- Receiver: 12
- Provider: 16
- `android.permission.INTERNET`, `RECORD_AUDIO`, bildirim, depolama, ağ, Bluetooth, wake lock, exact alarm, Google Play Billing ve Play license izinleri mevcut.
- Kamera için doğrudan `android.permission.CAMERA` yok. APK `image_picker` provider ve `capture` benzeri uygulama akışı kullanıyor olabilir; sistem kamera Intent'i senaryosunda uygulama CAMERA izni zorunlu olmayabilir. Runtime test olmadan kamera davranışı kesinleştirilmedi.

## Diller
17 gerçek dil JSON kaynağı bulundu: `ar, de, en, es, es-419, fr, id, it, ja, ko, pt, pt-BR, ro, ru, tr, vi, zh`.

## Yetenek denetimi
| # | İddia | Dosyada kanıt | Çalışma kanıtı | Durum |
|---|---|---|---|---|
| 1 | Sohbet arayüzü | `chat_page_title`, `chat_textbox_hint`, mesaj eylemleri, history kaynakları | ABI/density splitler eksik; çalıştırılmadı | ÇALIŞMA TESTİ GEREKİYOR |
| 2 | Model seçimi | `llm_selection_title`, model ikonları ve model adları | Çalıştırılmadı | KISMİ |
| 3 | Çoklu model etiketleri | GPT/OpenAI, Claude, Gemini, Llama, DeepSeek, Grok, Perplexity etiketleri | Sunucu yönlendirmesi görülmedi | KISMİ |
| 4 | 17 dil desteği | 17 adet `assets/languages/*.json` | Kaynak dosyaları parse edildi | DOĞRULANDI |
| 5 | Dosya yükleme | `add_file`, `file_input_count_warning`, FileProvider/openfile bağımlılıkları | Çalıştırılmadı | KISMİ |
| 6 | Galeriden görsel | `add_image`, image_picker provider | Çalıştırılmadı | KISMİ |
| 7 | Kamera | `add_camera`, camera ikonları, image_picker provider | CAMERA izni yok; telefon testi yok | ÇALIŞMA TESTİ GEREKİYOR |
| 8 | Video girişi | `add_image_or_video`, video duration/size/limit metinleri | Çalıştırılmadı | KISMİ |
| 9 | Ses dosyası girişi | `audio_input_count_warning`, `add_audio.svg` | Çalıştırılmadı | KISMİ |
| 10 | Mikrofon kaydı | `RECORD_AUDIO`, `record_web`, Android record sınıfları | Çalıştırılmadı | KISMİ |
| 11 | Voice Chat | Voice Chat metinleri, SpeechRecognizer, TextToSpeech, just_audio/audio_session | Çalıştırılmadı | KISMİ |
| 12 | Sesli dil tanıma | `Language Recognition`, speech-to-text izleri | Çalıştırılmadı | KISMİ |
| 13 | Yapay zekâ görsel üretimi | AI Art kaynakları, prompt/style görselleri | Üretim backend'i görülmedi | KISMİ |
| 14 | Görsel düzenleme/dönüştürme | `pro_image_editor`, style transformation kaynakları | Çalıştırılmadı | KISMİ |
| 15 | Web Search | Web Search UI/metinleri ve internet izni | Gerçek arama servisi endpoint'i doğrulanmadı | ÇALIŞMA TESTİ GEREKİYOR |
| 16 | Deep Research | Deep Research UI/loading/completion/source metinleri | Backend doğrulanmadı | ÇALIŞMA TESTİ GEREKİYOR |
| 17 | Memory | Memory/manage/clear/delete/update kaynakları | Depolama bağlama noktası doğrulanmadı | KISMİ |
| 18 | Personalization | İki kişiselleştirme sorusu ve global uygulama açıklaması | Çalıştırılmadı | KISMİ |
| 19 | Temporary Chat | Geçmişe/hafızaya yazmama açıklaması | Çalıştırılmadı | KISMİ |
| 20 | Chat History | History/filter/search UI kaynakları, sqflite bağımlılığı | Şema ve runtime doğrulanmadı | KISMİ |
| 21 | Yerel veri altyapısı | `sqflite`, `shared_preferences` sınıf/strings | Hangi verinin nerede tutulduğu tam bağlanmadı | DOĞRULANDI |
| 22 | Abonelik/Pro/paywall | Billing permission, BillingClient 8.0.0 metadata, paywall kaynakları | Satın alma işlemi yapılmadı | DOĞRULANDI |
| 23 | Bildirimler | POST_NOTIFICATIONS, FCM servisleri, local notification receiver'ları | Push gönderimi yapılmadı | DOĞRULANDI |
| 24 | Auth altyapısı | Firebase Auth activity'leri, Google Sign-In sınıfları, Facebook SDK | Kullanıcı hesap ekranı/akışı bulunamadı | KISMİ |
| 25 | OCR/metin tanıma | ML Kit text recognition common + Chinese/Japanese/Korean/Devanagari paketleri | Ürün akışına bağlandığı runtime kanıtı yok | DOĞRULANDI |
| 26 | Paylaşım/URL açma | share_plus/url_launcher provider/activity ve paylaşım metinleri | Çalıştırılmadı | DOĞRULANDI |
| 27 | Analitik/attribution | Firebase Analytics, Adjust, Smartlook | SDK bileşenleri mevcut | DOĞRULANDI |
| 28 | Güvenli ham API anahtarı kasası | APK'da bu tasarıma ait doğrulanmış kasa bulunamadı | Yok | BULUNAMADI |
| 29 | Mehmet'e özel Sahip kimliği | Orijinal botta bu proje modeline ait kanıt yok | Yok | BULUNAMADI |
| 30 | Standalone install edilebilir tam APK | `requiredSplitTypes=base__abi,base__density`; bu dosyada `lib/` yok | Tek APK telefon testi yapılamadı | BULUNAMADI |

## Model etiketleri hakkında kritik not
Dil kaynaklarında çok sayıda model adı bulunması, bu APK'nin o modellerin her birine doğrudan veya halen erişebildiğini kanıtlamaz. Bu kayıt yalnızca UI/konfigürasyon etiketi kanıtıdır. Model routing ve sunucu sonuçları runtime/network testi ile doğrulanmalıdır.

## Dış servis/SDK kanıtı
Firebase (Auth, Messaging, Analytics, Remote Config/Storage izleri), Google Sign-In/Credentials, Facebook SDK, Google Play Billing, Adjust, Smartlook, ML Kit, sqflite, shared_preferences, just_audio, record ve Flutter local notifications bileşenleri görüldü. Doğrudan OpenAI/Anthropic/Google Gemini model API endpoint'i bu base APK statik taramasında doğrulanmadı.

## Koruma / eksik parça bulgusu
`com.pairip.application.Application`, `com.pairip.licensecheck.LicenseActivity`, `CHECK_LICENSE` ve `IAP` başlıklı opak assetler Play dağıtım/koruma katmanına işaret ediyor. Ayrıca base APK ABI/density splitlerini zorunlu ilan ediyor. Bu nedenle bu tek dosyadan tam Dart AOT uygulama mantığını ve gerçek cihaz davranışını eksiksiz çıkarmak mümkün değil. Eksik split dosyaları runtime testinin temel engelidir.
