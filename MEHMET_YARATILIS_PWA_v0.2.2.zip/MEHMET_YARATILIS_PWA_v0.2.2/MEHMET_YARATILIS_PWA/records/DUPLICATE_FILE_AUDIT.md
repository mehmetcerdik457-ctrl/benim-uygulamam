# KANONİK KOPYA / DUPLICATE FILE AUDIT

## PROJECT_MANIFEST.json
- `1cE3VLTMopI_BxkUR6Pf_IThnJ5VjfThv` — created 2026-09-05, size 2188, SHA-256 `6b04211731cda7f7c2825ce7f05bc7cef716a8c2a23c4738c4763a1a7e2c6f88`; bootstrap governance ve connector audit içeriyor.
- `1HZShLFGU5dlFvcf1E4Rbmll1LQgCjXBT` — created 2026-09-06, size 545, SHA-256 `f39298b61de90cf43c1bfddf038bc98193faee3f3dd7f2efcd7269b406db35fc`; PWA v0.1 release durumu içeriyor.

## RUN_LEDGER.jsonl
- `1sW9j3QTJRJDuUs9FP-RhvazEaQ_OH7mw` — created 2026-09-05, size 1937, SHA-256 `f5937339cf8b4d1147f2059673f8b76cb8537d0dff8aa8a2636a38a491561ea8`; bootstrap olayları.
- `17lGVy2KQJgIXRp1_aWSIjGDV20qt2QKt` — created 2026-09-06, size 1288, SHA-256 `32592b0249a051568eb3f4975787554eb98d438327328e3db414f696c0315dcd`; APK/PWA v0.1 olayları.

## Çözüm
İçerikler rakip değil, ardışık tarihsel katmanlardır. İlk oluşturulan proje dosyaları tek aktif kanonik ID olarak korunacak ve iki akış birleştirilecektir. 6 Eylül PWA kopyaları silinmeden sürümlü v0.1 snapshot adına çevrilip mevcut `MEHMET_YARATILIS_PWA` alanına taşınacaktır.
