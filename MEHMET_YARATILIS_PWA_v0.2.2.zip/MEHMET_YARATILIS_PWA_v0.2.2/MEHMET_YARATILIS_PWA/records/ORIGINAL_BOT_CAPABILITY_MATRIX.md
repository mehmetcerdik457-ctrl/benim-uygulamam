# ORİJİNAL BOT → MEHMET PWA v0.2.1 YETENEK EŞLEŞTİRME

TOPLAM_ORİJİNAL_YETENEK=27
GERÇEK_ÇALIŞIYOR=0
KISMİ=14
BEKLEYEN_DIŞ_BAĞIMLILIK=4
YOK=9

> Not: Fiziksel telefon tarayıcı runtime kanıtı henüz alınmadığı için browser özellikleri statik/integration kod kanıtı olsa bile GERÇEK_ÇALIŞIYOR olarak yükseltilmedi.

| Orijinal bot yeteneği | MEHMET PWA karşılığı | Durum | Gerçek mekanizma | Test / kanıt |
|---|---|---|---|---|
| Çoklu dil (17 dil) | 17 locale UI | KISMİ | locales/core.json + applyLanguage | 17 locale ve tüm data-i18n anahtarları static test PASS; fiziksel telefon UI runtime bekliyor |
| Yerel veri altyapısı | IndexedDB + localStorage | KISMİ | 6 IndexedDB store + localStorage | Şema/kod PASS; fiziksel browser persistence runtime bekliyor |
| Abonelik / Google Play Billing | Karşılık yok | YOK | Yok | Yok |
| Bildirim altyapısı | Karşılık yok | YOK | Yok | Yok |
| OCR / ML Kit | Karşılık yok | YOK | Yok | Yok |
| Paylaşım / URL açma | Karşılık yok | YOK | Yok | Yok |
| Analytics / attribution | Bilinçli olarak eklenmedi | YOK | Yok | Yok |
| Model seçimi | Dinamik provider select | BEKLEYEN_DIŞ_BAĞIMLILIK | /api/providers; configured provider only | Fail-closed PASS; gerçek provider credential yok |
| Çoklu model etiketleri | Provider metadata | BEKLEYEN_DIŞ_BAĞIMLILIK | provider adapters | Mock adapter PASS; gerçek provider yok |
| Dosya yükleme | Dosya seçici + SHA-256 | KISMİ | File API + WebCrypto | Kod/static PASS; fiziksel telefon seçim runtime bekliyor |
| Galeri görseli | image/* seçici + önizleme | KISMİ | File API + object URL + SHA-256 | Yerel mekanizma mevcut; model vision payload yok |
| Video girişi | Genel file input | KISMİ | File API + SHA-256 | Dosya seçilebilir; model video işleme yok |
| Ses dosyası girişi | Genel file input | KISMİ | File API + SHA-256 | Dosya seçilebilir; model audio işleme yok |
| Mikrofon | Gerçek kayıt akışı | KISMİ | getUserMedia(audio) + MediaRecorder | Kod/integration static PASS; fiziksel telefon runtime bekliyor |
| Voice Chat | Kayıt + TTS bileşenleri | KISMİ | MediaRecorder + SpeechSynthesis | Tam sürekli çift yönlü voice loop yok |
| Ses dili seçimi | TTS dili aktif UI dilini kullanır | KISMİ | SpeechSynthesisUtterance.lang | Kod PASS; cihaz voice runtime bekliyor |
| AI görsel üretimi | Karşılık yok | YOK | Yok | Yok |
| Görsel düzenleme | Karşılık yok | YOK | Yok | Yok |
| Memory | Kalıcı hafıza paneli | KISMİ | IndexedDB memory store | Yaz/oku kodu PASS; telefon reopen runtime bekliyor |
| Personalization | Tema/font/hafıza/haptic | KISMİ | localStorage + gerçek event handlerlar | Static regression PASS; haptic cihaz runtime bekliyor |
| Temporary Chat | Karşılık yok | YOK | Yok | Yok |
| Chat History | IndexedDB chats + restore | KISMİ | restoreChats() | v0.1 restore hatası düzeltildi; telefon kapat/aç runtime bekliyor |
| Kimlik doğrulama / hesap altyapısı | Sahip veri modeli + fail-closed gate | KISMİ | owner_identity.py | Owner challenge 423 PASS; güçlü auth unprovisioned |
| Gerçek sohbet backend | Secure bridge chat | BEKLEYEN_DIŞ_BAĞIMLILIK | /api/chat + provider adapter + vault | Provider yokken sahte yanıt yok; gerçek model credential yok |
| Kamera | Canlı kamera + JPEG capture | KISMİ | getUserMedia(video) + canvas.toBlob | Kod/static PASS; fiziksel telefon runtime bekliyor |
| Web Search | Research adapter | BEKLEYEN_DIŞ_BAĞIMLILIK | /api/research | Provider yokken disabled + 503 PASS |
| Deep Research | Ayrı derin araştırma motoru yok | YOK | Yok | Yok |
