# PHONE_RUNTIME_ACCEPTANCE — v0.2.1
Current status: NOT_EXECUTED_NO_CONNECTED_PHYSICAL_PHONE

Required trusted-HTTPS phone sequence:
1. Open HTTPS URL; secureContext must be PASS.
2. Install PWA.
3. Send local chat input; when no provider exists, no fake assistant/model answer may appear.
4. Fully close and reopen; previous chat and reopen probe must return.
5. Select a file; visible SHA-256 must be produced.
6. Camera permission -> live preview -> capture -> nonempty JPEG attachment.
7. Microphone permission -> record -> stop -> nonempty audio attachment.
8. TTS -> onstart -> onend / audible completion.
9. Switch among representative tr/en/ar/ja and verify navigation/button/placeholder changes; then complete all 17 locale selection smoke tests.
10. Open once online, go offline, fully close/reopen; shell must open from service-worker cache.
11. Confirm Task History records real events and Error Log records real failures with secrets redacted.
12. Owner critical action remains disabled/unprovisioned.
