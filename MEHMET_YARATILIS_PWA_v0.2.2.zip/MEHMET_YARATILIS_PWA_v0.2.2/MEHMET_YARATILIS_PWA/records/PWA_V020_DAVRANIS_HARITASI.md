# PWA v0.2.0 DAVRANIŞ HARİTASI

## Sohbet
KULLANICI → metin yazar → UI mesajı `chats` IndexedDB'ye yazar → `/api/chat` bridge → provider registry → server-side vault secret çözer → gerçek provider yapılandırılmışsa cevap → UI + `chats` + audit task/log. Provider yoksa HTTP 503 → sistem uyarısı → sahte assistant cevabı üretilmez.

## Kalıcı sohbet/hafıza
Açılış → aynı `mehmet_pwa_v1` DB (v2 migration) → `restoreChats()` son kayıtları UI'ye getirir → `persistenceProbe()` localStorage işareti ile önceki browser çalıştırmasının IndexedDB kaydını karşılaştırır. Bu sandboxta browser navigasyonu bloklu olduğundan process-reopen runtime PASS verilmedi.

## Dosya/Görsel
KULLANICI → file picker → File API → ArrayBuffer → WebCrypto SHA-256 → attachment metadata/preview → task audit. Bu sürüm model adapterına dosya içeriği değil yalnız doğrulanmış metadata/hash gider; multimodal provider upload **uygulanmış sayılmaz**.

## Kamera
KULLANICI → kamera düğmesi → `getUserMedia(video)` → izin/cihaz akışı → video preview → canvas JPEG yakalama → File + SHA-256 → attachment. Fiziksel runtime bu ortamda BLOCKED.

## Mikrofon
KULLANICI → mikrofon → `getUserMedia(audio)` → MediaRecorder → Blob/File → SHA-256 → attachment. Fiziksel runtime BLOCKED.

## TTS
KULLANICI → ses → `speechSynthesis` → tarayıcı/OS ses motoru. API kodu gerçek; fiziksel çıktı runtime UNVERIFIED.

## Web Research
KULLANICI → sorgu → research düğmesi yalnız `/api/providers` `research_configured=true` ise aktif → `/api/research` → server adapter/vault → sonuç → UI/audit. Provider yoksa düğme disabled ve sahte sonuç yok.

## Sahip Kimliği
UI → `/api/owner/status` → OwnerIdentity veri modeli: OWNER_ID, TRUSTED_DEVICE_ID, SESSION_ID, SESSION_EXPIRY, AUTH_LEVEL, CHALLENGE_ID, CHALLENGE_EXPIRY, AUTH_METHOD, LAST_VERIFIED_AT, AUDIT_ID. Provision yoksa challenge 423 fail-closed.
